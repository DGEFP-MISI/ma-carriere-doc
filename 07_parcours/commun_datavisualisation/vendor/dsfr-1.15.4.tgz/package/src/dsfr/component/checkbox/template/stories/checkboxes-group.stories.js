import { checkboxesGroupArgs, checkboxesGroupArgTypes, checkboxesGroupProps, getCheckboxesData } from './checkboxes-group-arg-types';
import { renderFieldset } from '../../../form/template/stories/fieldset';

const render = (args) => renderFieldset({ fieldset: checkboxesGroupProps(args) });

export default {
  id: 'checkboxes-group',
  title: 'DSFR/Component/Checkbox/Checkboxes-Group',
  render: render,
  argTypes: checkboxesGroupArgTypes,
  args: checkboxesGroupArgs
};

export const CheckboxesGroupStory = {
  tags: ['!autodocs'],
  args: {
  }
};

export const DefaultGroupStory = {
  tags: ['autodocs', '!dev'],
  args: {
    checkboxes: getCheckboxesData()
  }
};

export const HintStory = {
  tags: ['autodocs', '!dev'],
  args: {
    hint: 'Texte de description additionnel',
    checkboxes: getCheckboxesData()
  }
};

export const HintGroupStory = {
  tags: ['autodocs', '!dev'],
  args: {
    checkboxes: getCheckboxesData(3, true)
  }
};

export const InlineStory = {
  tags: ['autodocs', '!dev'],
  args: {
    inline: true,
    checkboxes: getCheckboxesData(2)
  }
};

export const SizeMdStory = {
  tags: ['autodocs', '!dev'],
  args: {
    size: 'md',
    checkboxes: getCheckboxesData()
  }
};

export const SizeSmStory = {
  tags: ['autodocs', '!dev'],
  args: {
    size: 'sm',
    checkboxes: getCheckboxesData()
  }
};

export const DisabledStory = {
  tags: ['autodocs', '!dev'],
  args: {
    checkboxes: getCheckboxesData(),
    disabled: true
  }
};

export const ErrorStory = {
  tags: ['autodocs', '!dev'],
  args: {
    status: 'error',
    checkboxes: getCheckboxesData()
  }
};

export const SuccessStory = {
  tags: ['autodocs', '!dev'],
  args: {
    status: 'valid',
    checkboxes: getCheckboxesData()
  }
};
