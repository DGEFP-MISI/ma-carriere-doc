# Explorer V2 — backlog de user stories

**Mise à jour du 2 novembre 2026 — dossier rangé.** Le lot L0 est terminé. La présentation actuelle est la [maquette HTML citoyenne](12_maquette_html/index.html), dont les [sources et contrôles](12_maquette_html/README.md) sont rangés séparément. Voir le [guide du dossier](README.md). Les noms du projet, identifiants et référentiels employés dans les documents techniques ne doivent pas apparaître dans les écrans citoyens. Les 31 fonctionnalités restent conservées ; les captures locales ne valent pas des tests HTTP de l’API.

Alignement L0 — 1er novembre 2026. **Les 31 stories US-E01–US-E31 sont dans la cible validée.** Aucun groupe d'exclusion ou de report. Les lots L2–L9 sont techniques ; L0/L1/L10 assurent alignement, intégration et recette. Les modalités D02–D10 restent ouvertes sans retirer de story. Les critères historiques utiles sont conservés et complétés dans 03 ; le niveau de preuve ne valide pas une intégration HTTP générale.

## EPIC 1 — Recherche et sélection

**US-E01 — Quel métier ?**

En tant que personne qui explore son avenir professionnel, je veux identifier un métier à partir de son nom ou d'une appellation.

- Fonction : Recherche de métiers. Lot : **L2** ; cible : incluse.
- API : `/metiers` (q, page). Champs et contraintes exacts : ligneE01 de03, Appels_GET_detail, et02.
- Interactions : Recherche de métiers ; Recherche unique, résultats identifiés, ouvrir la fiche choisie ; nouvelles recherches depuis la fiche.
- Dépendances : aucune.
- Acceptation : Une sélection explicite ouvre la fiche; 0 résultat affiche issue ; Recherche unique, résultats identifiés, ouvrir la fiche choisie ; nouvelles recherches depuis la fiche ; Capturer préfixes/accents/mots multiples, 0 résultat et pagination ; valider annulation des anciennes réponses ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Référentiel ROME V3 ; aucun indicateur numérique inféré de la pertinence.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D ; recherche `q` à tester**. Preuves : `01_sources/openapi/docs_json_interface.json` ; `03_catalogue/routes_openapi.csv`.
- Test à exécuter : T-E01 : Capturer préfixes/accents/mots multiples, 0 résultat et pagination ; valider annulation des anciennes réponses
- Clarification : Q02 : recherche et version du référentiel ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Référentiel ROME V3 ; aucun indicateur numérique inféré de la pertinence. ; Qualité des recherches approximatives non validée

**US-E02 — Quel diplôme ?**

En tant que personne qui explore son avenir professionnel, je veux retrouver une certification et identifier son type.

- Fonction : Recherche de certifications. Lot : **L2** ; cible : incluse.
- API : `/certifications` (q, page). Champs et contraintes exacts : ligneE02 de03, Appels_GET_detail, et02.
- Interactions : Recherche de certifications ; Résultat avec type, RNCP/RS et code ; conserver l'intention de consultation en ouvrant la fiche.
- Dépendances : aucune.
- Acceptation : Un certificat sélectionné ouvre /certifications/{certifinfo} ; Résultat avec type, RNCP/RS et code ; conserver l'intention de consultation en ouvrant la fiche ; Recherches représentatives dont titre/RS et plusieurs résultats ; distinguer non trouvé et erreur ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Certification active RNCP/RS ; type et niveau ne sont pas un score ; pas d'archive exposée.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J ; `q` à tester**. Preuves : `02_reponses_observees/certifications/response_certifications.json`.
- Test à exécuter : T-E02 : Recherches représentatives dont titre/RS et plusieurs résultats ; distinguer non trouvé et erreur
- Clarification : Q02/Q09 : limites de recherche et certifications actives ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Certification active RNCP/RS ; type et niveau ne sont pas un score ; pas d'archive exposée. ; Pas de recherche sémantique promise

**US-E03 — Quel secteur ?**

En tant que personne qui explore son avenir professionnel, je veux découvrir un domaine professionnel sans connaître un métier.

- Fonction : Arbre et fiche Domaine. Lot : **L2** ; cible : incluse.
- API : `/domaines` (grand_domaine). Champs et contraintes exacts : ligneE03 de03, Appels_GET_detail, et02.
- Interactions : Arbre et fiche Domaine ; Grand domaine → domaine → fiche ; filtre local des libellés reçus comme proposition pour conserver une barre unique sans `q` serveur.
- Dépendances : aucune.
- Acceptation : Le libellé public Secteur indique clairement domaine professionnel ; Grand domaine → domaine → fiche ; filtre local des libellés reçus comme proposition pour conserver une barre unique sans `q` serveur ; Collecter l'arbre, vérifier codes/nombres/types contractuels ; tester sélection du sous-domaine ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. nb_metiers du contrat conservé ; aucun agrégat d'emploi par Domaine, total compte les grands domaines retournés.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement. Arbre non paginé, total grands domaines.
- Validation : **D ; T pour réponse réelle**. Preuves : `03_catalogue/routes_openapi.csv` ; `03_catalogue/modeles_reponses/domaines.schema.json`.
- Test à exécuter : T-E03 : Collecter l'arbre, vérifier codes/nombres/types contractuels ; tester sélection du sous-domaine
- Clarification : Q03 : export réel et règle `nb_metiers` ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : nb_metiers du contrat conservé ; aucun agrégat d'emploi par Domaine, total compte les grands domaines retournés. ; Structure documentée, aucun JSON réel collecté ; acquisition dans L2.

**US-E04 — Quels métiers du secteur ?**

En tant que personne qui explore son avenir professionnel, je veux voir les métiers d'un domaine et affiner la liste.

- Fonction : Métiers du domaine. Lot : **L2** ; cible : incluse.
- API : `/metiers` (domaine, page, competence, mode_competence, contexte, sans_contexte, q). Champs et contraintes exacts : ligneE04 de03, Appels_GET_detail, et02.
- Interactions : Métiers du domaine ; Métiers du domaine, filtres compétences/contextes combinables ; pagination progressive.
- Dépendances : E03.
- Acceptation : La liste ne contient que des métiers du domaine choisi ; Métiers du domaine, filtres compétences/contextes combinables ; pagination progressive ; Tracer domaine seul puis avec filtres, vérifier chaque `domaine_code` et toutes pages requises ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Référentiel ROME V3 ; pagination et filtrage ne créent aucun agrégat statistique.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J ciblé ; chaîne complète T**. Preuves : `04_relations/CHAINES_APPELS_API.md` ; `03_catalogue/routes_openapi.csv`.
- Test à exécuter : T-E04 : Tracer domaine seul puis avec filtres, vérifier chaque `domaine_code` et toutes pages requises
- Clarification : Q03/Q05 : combinaison et périmètre ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Référentiel ROME V3 ; pagination et filtrage ne créent aucun agrégat statistique. ; Lien documentaire non test R16-R24

## EPIC 2 — Trois fiches

**US-E05 — Que fait-on dans ce métier ?**

En tant que personne qui explore son avenir professionnel, je veux comprendre ce que recouvre un métier.

- Fonction : Fiche métier. Lot : **L2** ; cible : incluse.
- API : `/metiers/{rome}` (rome). Champs et contraintes exacts : ligneE05 de03, Appels_GET_detail, et02.
- Interactions : Fiche métier ; Définitions, appellations, domaine, savoir-être et contextes référencés ; actions vers tous les volets détaillés.
- Dépendances : E01/E04/E19/E07 selon entrée.
- Acceptation : N’affiche pas de valeur si absente; code ROME V3 visible ; Définitions, appellations, domaine, savoir-être et contextes référencés ; actions vers tous les volets détaillés ; Deux fiches supplémentaires et 404 ; rendre listes/valeurs absentes sans texte généré ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Définitions[] et libellés reçus ; pas de champ activites, aucun texte métier fabriqué.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J**. Preuves : `02_reponses_observees/metiers/response_metiers-rome.json`.
- Test à exécuter : T-E05 : Deux fiches supplémentaires et 404 ; rendre listes/valeurs absentes sans texte généré
- Clarification : Q01 : stabilité/version du référentiel ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Définitions[] et libellés reçus ; pas de champ activites, aucun texte métier fabriqué. ; Définitions en tableau; ne pas extrapoler

**US-E06 — Quelles compétences et contextes ?**

En tant que personne qui explore son avenir professionnel, je veux consulter toutes les catégories de compétences et les contextes référencés.

- Fonction : Compétences et contextes complets. Lot : **L2/L3** ; cible : incluse.
- API : `/metiers/{rome}/competences` (rome, categorie, coeur_metier, page). Champs et contraintes exacts : ligneE06 de03, Appels_GET_detail, et02.
- Interactions : Compétences et contextes complets ; Catégories, hiérarchie macro/enjeu/domaine quand reçue, part des spécialités et cœur de métier ; pas de compétence personnelle inférée.
- Dépendances : E05.
- Acceptation : Garder codes OGR et ne jamais exposer ROME4 ; Catégories, hiérarchie macro/enjeu/domaine quand reçue, part des spécialités et cœur de métier ; pas de compétence personnelle inférée ; Collecter page 2 F1610 et une seconde fiche complète ; tester chaque catégorie et cœur, `tag_coeur_metier=null` ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. tx_fiches_rome4 décrit la part des spécialités V3, pas la maîtrise ; cœur nullable ; listes complètes pour comparaison.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement. Page manquante = liste incomplète, jamais compétence absente.
- Validation : **D+J partiel**. Preuves : `02_reponses_observees/metiers/response_metiers{rome}competences.json`.
- Test à exécuter : T-E06 : Collecter page 2 F1610 et une seconde fiche complète ; tester chaque catégorie et cœur, `tag_coeur_metier=null`
- Clarification : Q04 : exhaustivité et portée des tags ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : tx_fiches_rome4 décrit la part des spécialités V3, pas la maîtrise ; cœur nullable ; listes complètes pour comparaison. ; Ne déduit pas la maîtrise utilisateur

**US-E07 — Quels métiers proches ?**

En tant que personne qui explore son avenir professionnel, je veux découvrir et ouvrir des métiers proches.

- Fonction : Métiers proches. Lot : **L2** ; cible : incluse.
- API : `/metiers/{rome}` (rome). Champs et contraintes exacts : ligneE07 de03, Appels_GET_detail, et02.
- Interactions : Métiers proches ; Alternatives ordonnées comme reçues, ouverture/ajout aux pistes ; pas d'appel par carte pour un libellé déjà présent.
- Dépendances : E05.
- Acceptation : Chaque métier proche est ouvrable; aucun score ; Alternatives ordonnées comme reçues, ouverture/ajout aux pistes ; pas d'appel par carte pour un libellé déjà présent ; Ouvrir effectivement plusieurs cibles ; tester doublons éventuels/404 sans inventer d'autre proximité ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Proximité documentaire ordonnée comme reçue, distincte d'un flux de mobilité observé.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J pour codes ; ouverture des cibles T**. Preuves : `02_reponses_observees/metiers/response_metiers-rome.json` ; `04_relations/CHAINES_APPELS_API.md`.
- Test à exécuter : T-E07 : Ouvrir effectivement plusieurs cibles ; tester doublons éventuels/404 sans inventer d'autre proximité
- Clarification : Q01 si divergence de codes entre liste et détail ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Proximité documentaire ordonnée comme reçue, distincte d'un flux de mobilité observé. ; Proximité ne prouve pas mobilité observée

**US-E17 — Que contient cette certification ?**

En tant que personne qui explore son avenir professionnel, je veux examiner une certification selon que je la possède ou souhaite l'obtenir.

- Fonction : Fiche Certification et résultats. Lot : **L2** ; cible : incluse.
- API : `/certifications/{certifinfo}` (certifinfo) ; `/mesures` (fields facultatif). Champs et contraintes exacts : ligneE17 de03, Appels_GET_detail, et02.
- Interactions : Fiche Certification et résultats ; Deux intentions, statut et voies, insertion scolaire/apprentissage/InserSup/DE séparée, résultats disponibles et masqués ; enrichissements salariaux InserSup à leurs horizons propres.
- Dépendances : E02/E20/E30 selon entrée;E31.
- Acceptation : La bascule ne modifie aucune donnée ; Deux intentions, statut et voies, insertion scolaire/apprentissage/InserSup/DE séparée, résultats disponibles et masqués ; enrichissements salariaux InserSup à leurs horizons propres ; Cas RNCP/RS, multi-ROME, champs null/secrets, anciennes certifications introuvables ; tests des populations et promotions ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Toutes mesures nationales par population : IJ scolaire/apprentissage distincts, InserSup et DE distincts ; emploi12m/acces6m/poursuite/réussite/salaires/admissions non fusionnés ; millésimes MES propres, secrets et promotions conservés.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement. 404 peut concerner certification inactive, aucune archive présumée.
- Validation : **D+J pour détail ; couverture fonctionnelle partielle**. Preuves : `02_reponses_observees/certifications/response_certifications-certifinfo.json` ; `02_reponses_observees/indicateurs/Recrutementregions/response_mesures.json`.
- Test à exécuter : T-E17 : Cas RNCP/RS, multi-ROME, champs null/secrets, anciennes certifications introuvables ; tests des populations et promotions
- Clarification : Q09 : cycle actif, périodes/coverage insertion ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Toutes mesures nationales par population : IJ scolaire/apprentissage distincts, InserSup et DE distincts ; emploi12m/acces6m/poursuite/réussite/salaires/admissions non fusionnés ; millésimes MES propres, secrets et promotions conservés. ; Rattachement à métier ≠ accès garanti emploi

**US-E18 — Quels blocs et compétences certifiés ?**

En tant que personne qui explore son avenir professionnel, je veux comprendre les blocs certifiés et retrouver des certifications par leur texte.

- Fonction : Blocs RNCP et recherche textuelle. Lot : **L2/L3** ; cible : incluse.
- API : `/certifications/blocs` (certifinfo, fiche, q, page). Champs et contraintes exacts : ligneE18 de03, Appels_GET_detail, et02.
- Interactions : Blocs RNCP et recherche textuelle ; Blocs RNCP, texte des compétences et évaluation, navigation vers `certifinfo_codes[]` ; trouver une certification via le texte publié d'un bloc.
- Dépendances : E17 ou recherche texte directe.
- Acceptation : Ne jamais fusionner bloc RNCP et OGR ; Blocs RNCP, texte des compétences et évaluation, navigation vers `certifinfo_codes[]` ; trouver une certification via le texte publié d'un bloc ; Capturer filtres exacts ; vérifier 4 blocs RNCP36101 et absence de blocs publiés ; recherche texte, pagination ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. competences/modalites_evaluation sont textes RNCP, pas OGR ; pas de blocs RS ; null/absence bloc publié ne signifie pas aucune compétence.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J pour quatre blocs ; filtre exact T**. Preuves : `02_reponses_observees/certifications/response_certificationsblocs.json`.
- Test à exécuter : T-E18 : Capturer filtres exacts ; vérifier 4 blocs RNCP36101 et absence de blocs publiés ; recherche texte, pagination
- Clarification : Q10 : filtres et couverture des blocs ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : competences/modalites_evaluation sont textes RNCP, pas OGR ; pas de blocs RS ; null/absence bloc publié ne signifie pas aucune compétence. ; Absence bloc ≠ absence de compétence

**US-E19 — Quels métiers sont associés ?**

En tant que personne qui explore son avenir professionnel, je veux ouvrir les métiers associés à une certification.

- Fonction : Métiers associés à une certification. Lot : **L2** ; cible : incluse.
- API : `/metiers/{rome}` (rome). Champs et contraintes exacts : ligneE19 de03, Appels_GET_detail, et02.
- Interactions : Métiers associés à une certification ; Tous les métiers associés en liens, sans garantir accès à l'emploi ; réutiliser le cache.
- Dépendances : E17.
- Acceptation : Aucune garantie emploi; ouverture réelle fiche ; Tous les métiers associés en liens, sans garantir accès à l'emploi ; réutiliser le cache ; Certification à plusieurs ROME, ouverture des cibles ; ne pas dépendre du seul `rome_code` nullable ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Association rome_codes[] multiple, non-garantie d'accès à l'emploi ; ne pas dépendre de rome_code nullable.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J statique, chaîne T**. Preuves : `04_relations/CHAINES_APPELS_API.md` ; `02_reponses_observees/certifications/response_certifications-certifinfo.json`.
- Test à exécuter : T-E19 : Certification à plusieurs ROME, ouverture des cibles ; ne pas dépendre du seul `rome_code` nullable
- Clarification : Q09 si relation contradictoire ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Association rome_codes[] multiple, non-garantie d'accès à l'emploi ; ne pas dépendre de rome_code nullable. ; Association documentaire non garantie causale

**US-E20 — Quelles certifications sont associées au métier ?**

En tant que personne qui explore son avenir professionnel, je veux explorer les certifications associées à un métier et leurs voies d'accès.

- Fonction : Certifications associées au métier. Lot : **L2/L3** ; cible : incluse.
- API : `/certifications` (rome, acces, validation_partielle, repertoire, page). Champs et contraintes exacts : ligneE20 de03, Appels_GET_detail, et02.
- Interactions : Certifications associées au métier ; Certifications associées au métier, voies et validation partielle filtrables ; accès aux blocs/fiches/sessions.
- Dépendances : E05.
- Acceptation : Pas de promesse de diplôme requis ; Certifications associées au métier, voies et validation partielle filtrables ; accès aux blocs/fiches/sessions ; ROME exact + filtres d'accès/validation, pages et RNCP/RS ; ne pas transformer en diplôme obligatoire ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Association active, pas diplôme obligatoire ni éligibilité individuelle ; validation_partielle et acces sont filtres documentés.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J statique, filtre T**. Preuves : `04_relations/CHAINES_APPELS_API.md` ; `02_reponses_observees/certifications/response_certifications.json`.
- Test à exécuter : T-E20 : ROME exact + filtres d'accès/validation, pages et RNCP/RS ; ne pas transformer en diplôme obligatoire
- Clarification : Q09/Q10 : filtrage et validation partielle ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Association active, pas diplôme obligatoire ni éligibilité individuelle ; validation_partielle et acces sont filtres documentés. ; Recensement non exhaustif des voies possibles

## EPIC 3 — Indicateurs et comparaisons territoriales

**US-E09 — Quel territoire examiner ?**

En tant que personne qui explore son avenir professionnel, je veux choisir un territoire précis et comprendre ses périmètres disponibles.

- Fonction : Sélection territoriale. Lot : **L2** ; cible : incluse.
- API : `/territoires` (q, zonage, region, departement, clpe, code, page). Champs et contraintes exacts : ligneE09 de03, Appels_GET_detail, et02.
- Interactions : Sélection territoriale ; Choix explicite ; proposer les périmètres autorisés dans chaque volet en nommant le parent ; France pour routes compatibles.
- Dépendances : aucune.
- Acceptation : Choix explicite; France sans code si admis ; Choix explicite ; proposer les périmètres autorisés dans chaque volet en nommant le parent ; France pour routes compatibles ; Homonymes, commune/CLPE/Corse/DOM ; absence de parent et incompatibilité de zonage ; pas de recherche code postal ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Territoire de sélection distinct du territoire effectivement mesuré ; pas de population ou distance inférée.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J ; V sur code 34172, `q` T**. Preuves : `02_reponses_observees/territoires/response_regions.json`.
- Test à exécuter : T-E09 : Homonymes, commune/CLPE/Corse/DOM ; absence de parent et incompatibilité de zonage ; pas de recherche code postal
- Clarification : Q03/Q06 : référentiel territorial et parents ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Territoire de sélection distinct du territoire effectivement mesuré ; pas de population ou distance inférée. ; Les zonages acceptés varient par endpoint

**US-E08 — Quels indicateurs pour ce métier et mon territoire ?**

En tant que personne qui explore son avenir professionnel, je veux comprendre le marché du travail au territoire réellement mesuré.

- Fonction : Indicateurs territoriaux complets. Lot : **L4** ; cible : incluse.
- API : `/indicateurs` (rome, zonage, territoire, onisep). Champs et contraintes exacts : ligneE08 de03, Appels_GET_detail, et02.
- Interactions : Indicateurs territoriaux complets ; Synthèse questionnelle puis accès à toutes les mesures exposées, chacune avec ses valeurs, source, grain, période et lieu effectif.
- Dépendances : E05;E09;E31.
- Acceptation : Afficher maille réelle source année secret_stat séparément ; Synthèse questionnelle puis accès à toutes les mesures exposées, chacune avec ses valeurs, source, grain, période et lieu effectif ; Étendre R16 à autre ROME/territoire dont cas sans valeur ; vérifier toutes variantes des 14 mesures documentées, pas seulement une structure commune ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Formes de valeurs[] par mesure, grain rome/fap_228/fap_225/fap_87, maille_reelle/repli par mesure ; nb_rome_famille et familles multiples ; unités de la définition, pas de champ unite supposé.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **V sur F1610/34172, avec précautions**. Preuves : `06_controles/VALIDATION_R16_territoires_indicateurs.md` ; `02_reponses_observees/indicateurs/Recrutementregions/response_indicateurs.json` ; `06_controles/resultats/R16 test/GET_indicateurs__rome_F1610__zonage_commune__territoire_34172.json`.
- Test à exécuter : T-E08 : Étendre R16 à autre ROME/territoire dont cas sans valeur ; vérifier toutes variantes des 14 mesures documentées, pas seulement une structure commune
- Clarification : Q06 : repli et métadonnées/secret ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Formes de valeurs[] par mesure, grain rome/fap_228/fap_225/fap_87, maille_reelle/repli par mesure ; nb_rome_famille et familles multiples ; unités de la définition, pas de champ unite supposé. ; Validé seulement F1610/Montpellier; vérifier autres ROME

**US-E10 — Où y a-t-il des projets de recrutement ?**

En tant que personne qui explore son avenir professionnel, je veux examiner les projets de recrutement et leurs difficultés ou saisonnalité.

- Fonction : Classements des recrutements BMO. Lot : **L4** ; cible : incluse.
- API : `/recrutements` (rome, zonage, region, departement, tri). Champs et contraintes exacts : ligneE10 de03, Appels_GET_detail, et02.
- Interactions : Classements des recrutements BMO ; Projets, difficultés, saisonniers ; tris fournis et référence France ; rang par FAP228.
- Dépendances : E05;E09;E31.
- Acceptation : Aucun score; source/grain/millésime affichés ; Projets, difficultés, saisonniers ; tris fournis et référence France ; rang par FAP228 ; Tracer périmètres compatibles et 422 incompatible ; plusieurs familles ; zéro/taux saisonnier observé ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. BMO 2026 fap_228, projets et non offres/embauches ; rang et France par famille ; volumes arrondis, taux fournis non recalculés.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J, chaîne R05 non retestée HTTP**. Preuves : `02_reponses_observees/indicateurs/Recrutementregions/response_Recrutement france region Projet.json`.
- Test à exécuter : T-E10 : Tracer périmètres compatibles et 422 incompatible ; plusieurs familles ; zéro/taux saisonnier observé
- Clarification : Q07 : arrondis/dénominateurs et précision des petits volumes ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : BMO 2026 fap_228, projets et non offres/embauches ; rang et France par famille ; volumes arrondis, taux fournis non recalculés. ; Même famille peut correspondre à plusieurs ROME

**US-E11 — Où les salaires médians sont-ils plus élevés ?**

En tant que personne qui explore son avenir professionnel, je veux consulter les salaires et comparer les territoires par famille.

- Fonction : Classements des salaires. Lot : **L4** ; cible : incluse.
- API : `/salaires` (rome, zonage, region). Champs et contraintes exacts : ligneE11 de03, Appels_GET_detail, et02.
- Interactions : Classements des salaires ; Classements par FAP225, référence France, médiane mensuelle et distribution annuelle distinctes ; tranche ouverte explicite.
- Dépendances : E05;E09;E31.
- Acceptation : Pas de mélange unités mensuelles et annuelles ; Classements par FAP225, référence France, médiane mensuelle et distribution annuelle distinctes ; tranche ouverte explicite ; Cas tranche ouverte et seuil territorial ; région seule vs départements d'une région ; préserver `rang` et null ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. BTS 2023 fap_225 ; médiane mensuelle distincte des Q1/médiane/Q3 annuels ; tranche ouverte >50000 EUR annuels si médiane null ; conserver rang, seuil 30 observations échantillon.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement. null avec tranche ouverte = afficher tranche, pas salaire inventé.
- Validation : **D+J, chaîne R06 non retestée HTTP**. Preuves : `02_reponses_observees/indicateurs/salaires/response_regions.json`.
- Test à exécuter : T-E11 : Cas tranche ouverte et seuil territorial ; région seule vs départements d'une région ; préserver `rang` et null
- Clarification : Q08 : seuils, tranche et rang ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : BTS 2023 fap_225 ; médiane mensuelle distincte des Q1/médiane/Q3 annuels ; tranche ouverte >50000 EUR annuels si médiane null ; conserver rang, seuil 30 observations échantillon. ; Les quartiles annuels ne sont pas quartiles mensuels

**US-E12 — Les données sont-elles comparables ?**

En tant que personne qui explore son avenir professionnel, je veux comprendre quand deux valeurs décrivent des populations comparables.

- Fonction : Comparabilité des données. Lot : **L4** ; cible : incluse.
- API : `/mesures` (fields facultatif). Champs et contraintes exacts : ligneE12 de03, Appels_GET_detail, et02.
- Interactions : Comparabilité des données ; Expliquer pourquoi deux valeurs sont ou ne sont pas comparables ; préciser bases et populations sans score.
- Dépendances : E08;E10;E11;E31.
- Acceptation : Alerte visible en cas de grilles non comparables ; Expliquer pourquoi deux valeurs sont ou ne sont pas comparables ; préciser bases et populations sans score ; Comparaison même famille, familles différentes, périodes/mailles différentes ; tester catalogue indisponible ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Comparabilité par mesure, unité, période, population, famille et territoire réel ; même FAP = même observation ; aucune soustraction inter-grains.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J, décision de comparaison à spécifier**. Preuves : `02_reponses_observees/indicateurs/Recrutementregions/response_mesures.json`.
- Test à exécuter : T-E12 : Comparaison même famille, familles différentes, périodes/mailles différentes ; tester catalogue indisponible
- Clarification : Q06 : correspondance métadonnées et évolutions ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Comparabilité par mesure, unité, période, population, famille et territoire réel ; même FAP = même observation ; aucune soustraction inter-grains. ; Catalogue ne prouve pas chaque résultat territoire

**US-E31 — Comment lire les mesures disponibles et leurs limites ?**

En tant que personne qui explore son avenir professionnel, je veux retrouver les définitions et limites des mesures effectivement reçues.

- Fonction : Catalogue et méthodologie des mesures. Lot : **L4** ; cible : incluse.
- API : `/mesures` (fields facultatif). Champs et contraintes exacts : ligneE31 de03, Appels_GET_detail, et02.
- Interactions : Catalogue et méthodologie des mesures ; Méthodologie commune et disponibilité effective d'après réponses, consultable dans chaque volet.
- Dépendances : aucune.
- Acceptation : Aucune mesure disponible présumée ; Méthodologie commune et disponibilité effective d'après réponses, consultable dans chaque volet ; Vérifier que les 29 entrées historiques ne sont pas présumées toutes présentes sous `/indicateurs` ; nouvelles entrées tolérées ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Catalogue global29 entrées historiques, disponibilité locale lue dans valeurs[] ; code↔mesure et ressource ; source du catalogue différent de source_libelle des résultats.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J**. Preuves : `02_reponses_observees/indicateurs/Recrutementregions/response_mesures.json`.
- Test à exécuter : T-E31 : Vérifier que les 29 entrées historiques ne sont pas présumées toutes présentes sous `/indicateurs` ; nouvelles entrées tolérées
- Clarification : Q01/Q06 : schémas et version du catalogue ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Catalogue global29 entrées historiques, disponibilité locale lue dans valeurs[] ; code↔mesure et ressource ; source du catalogue différent de source_libelle des résultats. ; Schéma distinct d’une donnée mesurée

## EPIC 4 — Explorer par compétences et contextes

**US-E13 — Puis-je réutiliser certaines compétences ?**

En tant que personne qui explore son avenir professionnel, je veux sélectionner des compétences effectivement référencées.

- Fonction : Choix de compétences OGR. Lot : **L3** ; cible : incluse.
- API : `/competences` (q, code, categorie, domaine, enjeu, macro_competence, rome, page). Champs et contraintes exacts : ligneE13 de03, Appels_GET_detail, et02.
- Interactions : Choix de compétences OGR ; Choisir les OGR depuis le métier ou le catalogue ; voir leurs métiers associés sans conclure à une maîtrise.
- Dépendances : E06 ou recherche catalogue directe.
- Acceptation : Code 103659 validé, texte libre libre non inféré ; Choisir les OGR depuis le métier ou le catalogue ; voir leurs métiers associés sans conclure à une maîtrise ; Recherche libre et multi-code ; conserver zéro initial et catégories ; pas de correspondance RNCP par texte ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. OGR string 6 chiffres, 1–10 pour résolution code ; nb_metiers documenté, pas de maîtrise utilisateur.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **V sur `code=125416` et `103659` ; `q` T**. Preuves : `06_controles/VALIDATION_R23_recherche_multicompetences.md`.
- Test à exécuter : T-E13 : Recherche libre et multi-code ; conserver zéro initial et catégories ; pas de correspondance RNCP par texte
- Clarification : Q02/Q04 : recherche et codes ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : OGR string 6 chiffres, 1–10 pour résolution code ; nb_metiers documenté, pas de maîtrise utilisateur. ; Étiquettes des compétences sélectionnées

**US-E14 — Quels métiers ont ces compétences en commun ?**

En tant que personne qui explore son avenir professionnel, je veux retrouver les métiers portant tout ou partie des compétences sélectionnées.

- Fonction : Recherche multicompétences. Lot : **L3** ; cible : incluse.
- API : `/metiers` (competence, mode_competence, domaine, q, page). Champs et contraintes exacts : ligneE14 de03, Appels_GET_detail, et02.
- Interactions : Recherche multicompétences ; Choisir tous/au moins un ; montrer uniquement les correspondances renvoyées et le classement API par macro-compétences.
- Dépendances : E13.
- Acceptation : Test 125416+103659 toutes=1 au_moins_une=3 ; Choisir tous/au moins un ; montrer uniquement les correspondances renvoyées et le classement API par macro-compétences ; Rejouer R23 puis autres codes, 1/10/11 entrées, pagination et champs de match conditionnels ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Classement API nb_macro_competences_trouvees puis nb_competences_trouvees ; match conditionnel selon mode, aucun taux personnel calculé.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **V sur deux codes, avec précautions**. Preuves : `06_controles/VALIDATION_R23_recherche_multicompetences.md`.
- Test à exécuter : T-E14 : Rejouer R23 puis autres codes, 1/10/11 entrées, pagination et champs de match conditionnels
- Clarification : Q04 : classement et périmètre des correspondances ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Classement API nb_macro_competences_trouvees puis nb_competences_trouvees ; match conditionnel selon mode, aucun taux personnel calculé. ; Champs de match absents dans certains modes

**US-E15 — Quels contextes sont référencés ?**

En tant que personne qui explore son avenir professionnel, je veux choisir des conditions de travail référencées.

- Fonction : Choix de contextes OGR. Lot : **L3** ; cible : incluse.
- API : `/competences` (q, categorie, code, page). Champs et contraintes exacts : ligneE15 de03, Appels_GET_detail, et02.
- Interactions : Choix de contextes OGR ; Contextes libellés et explicites avant filtrage ; conserver distinction contextes/compétences.
- Dépendances : E06 ou recherche catalogue directe.
- Acceptation : Aucun texte libre arbitraire transmis comme code ; Contextes libellés et explicites avant filtrage ; conserver distinction contextes/compétences ; Capturer catalogue de contextes, vérifier catégorie et sélection ; pas d'alias arbitraire ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Catégorie contexte_travail, arborescence non applicable selon contrat ; pas de préférence libre convertie en OGR.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D ; sélection globale T**. Preuves : `06_controles/VALIDATION_R24_contextes_metiers.md` ; `03_catalogue/routes_openapi.csv`.
- Test à exécuter : T-E15 : Capturer catalogue de contextes, vérifier catégorie et sélection ; pas d'alias arbitraire
- Clarification : Q02/Q05 : recherche de contexte ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Catégorie contexte_travail, arborescence non applicable selon contrat ; pas de préférence libre convertie en OGR. ; Recherche catalogue contexte à collecter ; catégorie documentée, non à deviner.

**US-E16 — Quelles pistes avec/sans contexte ?**

En tant que personne qui explore son avenir professionnel, je veux chercher des métiers avec ou sans les contextes choisis.

- Fonction : Recherche avec/sans contexte. Lot : **L3** ; cible : incluse.
- API : `/metiers` (domaine, contexte, sans_contexte, competence, mode_competence, page). Champs et contraintes exacts : ligneE16 de03, Appels_GET_detail, et02.
- Interactions : Recherche avec/sans contexte ; Inclusion/exclusion de contextes référencés au parent V3 ; appliquer ensemble les sélections compatibles, expliquer absence non garantie dans tout emploi réel.
- Dépendances : E15;E03 si Domaine choisi.
- Acceptation : 300782 F16 avec=10 sans=3 ; expliquer limites ; Inclusion/exclusion de contextes référencés au parent V3 ; appliquer ensemble les sélections compatibles, expliquer absence non garantie dans tout emploi réel ; R24 puis multi-contextes/combinés ; re-test `fields` correctement encodé ; exclusion à l'échelle des spécialités ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Parent V3 : contexte porté par au moins une spécialité ; exclusion prudente si une spécialité le porte, absence de code non-garantie terrain.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **V sur F16/300782 sans `fields`**. Preuves : `06_controles/VALIDATION_R24_contextes_metiers.md`.
- Test à exécuter : T-E16 : R24 puis multi-contextes/combinés ; re-test `fields` correctement encodé ; exclusion à l'échelle des spécialités
- Clarification : Q05 : combinaison, projection et sémantique ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Parent V3 : contexte porté par au moins une spécialité ; exclusion prudente si une spécialité le porte, absence de code non-garantie terrain. ; Ne pas promettre absence réelle de conditions

## EPIC 5 — Mes pistes et comparaison complète

**US-E27 — Quelles pistes garder ?**

En tant que personne qui explore son avenir professionnel, je veux conserver temporairement des métiers pour poursuivre mon exploration.

- Fonction : Mes pistes temporaires. Lot : **L9** ; cible : incluse.
- API : `/metiers/{rome}` (rome). Champs et contraintes exacts : ligneE27 de03, Appels_GET_detail, et02.
- Interactions : Mes pistes temporaires ; Ajouter/retirer, conserver jusqu'à trois pistes proposé, comparer deux ; durée affichée selon décision de stockage.
- Dépendances : E05.
- Acceptation : Ajout/retrait; pas de collecte serveur; plafond fixé en D08 (trois proposé) ; Ajouter/retirer, conserver jusqu'à trois pistes proposé, comparer deux ; durée affichée selon décision de stockage ; Unicité, plafond, navigation/rechargement selon D08 ; aucun GET requis à chaque ajout ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Sélection de codes, pas mesure/statistique ; aucune sauvegarde serveur dans les 21 GET.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **Faisable en état local ; NC pour sauvegarde API**. Preuves : `02_reponses_observees/metiers/response_metiers-rome.json`.
- Test à exécuter : T-E27 : Unicité, plafond, navigation/rechargement selon D08 ; aucun GET requis à chaque ajout
- Clarification : Aucun blocage RCO ; aucune sauvegarde serveur parmi les 21 GET ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Sélection de codes, pas mesure/statistique ; aucune sauvegarde serveur dans les 21 GET. ; API ne propose pas d’enregistrement des favoris

**US-E28 — Quelles différences comptent ?**

En tant que personne qui explore son avenir professionnel, je veux comparer deux métiers sur leurs contenus, certifications et données statistiques.

- Fonction : Comparateur complet de deux métiers. Lot : **L9** ; cible : incluse.
- API : `/metiers/{rome}/competences` (rome, categorie, coeur_metier, page) ; `/metiers/{rome}` (rome) ; `/metiers/{rome}/competences` (rome, depuis, categorie, coeur_metier, page) ; `/indicateurs` (rome, zonage, territoire, onisep) ; `/recrutements` (rome, zonage, region, departement, tri) ; `/salaires` (rome, zonage, region) ; `/certifications` (rome, acces, validation_partielle, repertoire, page) ; `/mobilites` (rome, sens, region, age) ; `/prospective/regions` (rome, tri) ; `/salaires/secteurs` (rome, region) ; `/mesures` (fields facultatif). Champs et contraintes exacts : ligneE28 de03, Appels_GET_detail, et02.
- Interactions : Comparateur complet de deux métiers ; Comparateur complet par questions, accès détails mobilité/prospective/secteurs ; compétences communes et spécifiques sur listes complètes ; synthèse API directionnelle expliquée si utilisée.
- Dépendances : E27;E05;E06;E08;E09;E10;E11;E12;E17;E20;E23;E24;E25;E31.
- Acceptation : Comparer 2 métiers, source et année de chaque donnée ; Comparateur complet par questions, accès détails mobilité/prospective/secteurs ; compétences communes et spécifiques sur listes complètes ; synthèse API directionnelle expliquée si utilisée ; Deux jeux complets ; familles identiques/différentes, mailles/périodes différentes ; tester `depuis`, sens inverse et catégories ; aucun score personnel ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Listes complètes pour commun/spécifique ; depuis=relation directionnelle de métiers, jamais maîtrise ; chaque statistique conserve FAP/population/maille/période ; aucun score/delta calculé.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement. Page manquante = liste incomplète, jamais compétence absente. null avec tranche ouverte = afficher tranche, pas salaire inventé.
- Validation : **D pour données ; T pour comparaison complète**. Preuves : `02_reponses_observees/metiers/response_metiers{rome}competences.json` ; `01_sources/contrat_interface_2026-10-19.md`.
- Test à exécuter : T-E28 : Deux jeux complets ; familles identiques/différentes, mailles/périodes différentes ; tester `depuis`, sens inverse et catégories ; aucun score personnel
- Clarification : Q04/Q06 : comparaison et métadonnées ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Listes complètes pour commun/spécifique ; depuis=relation directionnelle de métiers, jamais maîtrise ; chaque statistique conserve FAP/population/maille/période ; aucun score/delta calculé. ; Différences d’exposition ≠ différences de maîtrise

## EPIC 6 — Sessions publiées à venir et en cours

**US-E21 — Quelles sessions à venir sont publiées ?**

En tant que personne qui explore son avenir professionnel, je veux consulter les sessions publiées à venir pour une certification.

- Fonction : Sessions à venir. Lot : **L8** ; cible : incluse.
- API : `/sessions_a_venir` (certifinfo, zonage, territoire, onisep, page). Champs et contraintes exacts : ligneE21 de03, Appels_GET_detail, et02.
- Interactions : Sessions à venir ; Sessions publiées à venir, dates, lieu, organisme, modalités ; mode Onisep séparé si consulté ; aucune place/inscription promise.
- Dépendances : E17;E09.
- Acceptation : Liste des sessions à venir avec paramètres tracés, dates et modalités ; filtres contrastés et garantie RCO de rattachement ; aucune place disponible promise ; Tests contrastés de certifications et territoires, temporalité, pagination, trois modes Onisep ; confirmation du filtre sans identifiant par ligne
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Ligne agrégée et nb_sessions distincts des places ; Onisep à date conventionnelle ; date de collecte connue ; pas d'ID stable inventé.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J, appel antérieur partiel ; T pour rattachement individuel**. Preuves : `06_controles/VALIDATION_R18_certifications_sessions_a_venir.md` ; `02_reponses_observees/sessions/response_sessions_a_venir.json`.
- Test à exécuter : T-E21 : Tests contrastés de certifications et territoires, temporalité, pagination, trois modes Onisep ; confirmation du filtre sans identifiant par ligne
- Clarification : Q11 : garantie et traçabilité contractuelle ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Ligne agrégée et nb_sessions distincts des places ; Onisep à date conventionnelle ; date de collecte connue ; pas d'ID stable inventé. ; R18 correspondance ligne à ligne non prouvée

**US-E22 — Quelles sessions en cours sont publiées ?**

En tant que personne qui explore son avenir professionnel, je veux consulter les sessions publiées en cours sans présumer d'une admission.

- Fonction : Sessions en cours. Lot : **L8** ; cible : incluse.
- API : `/sessions_en_cours` (certifinfo, zonage, territoire, onisep, page). Champs et contraintes exacts : ligneE22 de03, Appels_GET_detail, et02.
- Interactions : Sessions en cours ; Onglet en cours partageant sélection et composants E21, dates et modalités ; aucune admission déduite du statut temporel.
- Dépendances : E17;E09.
- Acceptation : Sans affirmation sur places ni inscriptions ; Onglet en cours partageant sélection et composants E21, dates et modalités ; aucune admission déduite du statut temporel ; Paire d'appels même contexte aux deux routes, date de référence, filtres ; pas de déduplication inter-vues inventée ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Session en cours distincte d'une admission ; mêmes limites d'agrégation/Onisep que E21 ; date de référence tracée.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J partiel ; T pour rattachement**. Preuves : `06_controles/VALIDATION_R19_certifications_sessions_en_cours.md` ; `02_reponses_observees/sessions/response_sessions_en_cours.json`.
- Test à exécuter : T-E22 : Paire d'appels même contexte aux deux routes, date de référence, filtres ; pas de déduplication inter-vues inventée
- Clarification : Q11 : règles temporelles et traçabilité ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Session en cours distincte d'une admission ; mêmes limites d'agrégation/Onisep que E21 ; date de référence tracée. ; R19 liaison non tracée par code

## EPIC 7 — Mobilités et prospective détaillée

**US-E23 — Quelles mobilités sont observées ?**

En tant que personne qui explore son avenir professionnel, je veux comprendre les origines et destinations professionnelles observées.

- Fonction : Mobilités professionnelles. Lot : **L5** ; cible : incluse.
- API : `/mobilites` (rome, sens, region, age). Champs et contraintes exacts : ligneE23 de03, Appels_GET_detail, et02.
- Interactions : Mobilités professionnelles ; Deux sens, âge, France/région, tableaux/graphiques par FAP225, situations hors emploi et parts incomplètes.
- Dépendances : E05;E09;E31.
- Acceptation : Population et âge expliqués ; Deux sens, âge, France/région, tableaux/graphiques par FAP225, situations hors emploi et parts incomplètes ; Tracer région et âges ; valider `maille/repli`, présence d'un seul couple origine/destination et libellés hors emploi ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. FAP225, 2022–2023 ; 15 situations au plus/famille, parts secret omises ; somme possiblement <100, pas de renormalisation ; âge fin période origines/début destinations ; tag_meme_metier=FAP.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J, appel avec filtres à tester**. Preuves : `02_reponses_observees/indicateurs/mobilites/response_destination.json` ; `02_reponses_observees/indicateurs/mobilites/response_origine.json`.
- Test à exécuter : T-E23 : Tracer région et âges ; valider `maille/repli`, présence d'un seul couple origine/destination et libellés hors emploi
- Clarification : Q12 : âges, repli, couverture des parts ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : FAP225, 2022–2023 ; 15 situations au plus/famille, parts secret omises ; somme possiblement <100, pas de renormalisation ; âge fin période origines/début destinations ; tag_meme_metier=FAP. ; Pas de mobilité ROME-Rome individuelle

**US-E24 — Croissance ou renouvellement ?**

En tant que personne qui explore son avenir professionnel, je veux explorer les perspectives détaillées à 2030 par métier et par région.

- Fonction : Prospective détaillée 2030. Lot : **L6** ; cible : incluse.
- API : `/prospective/regions` (rome, tri) ; `/prospective/metiers` (region, tri) ; `/metiers/{rome}` (rome). Champs et contraintes exacts : ligneE24 de03, Appels_GET_detail, et02.
- Interactions : Prospective détaillée 2030 ; Prospective détaillée par famille et région, effectifs/taux fournis, référence France, navigation vers ROME V3.
- Dépendances : E05 ou E09 selon entrée;E31.
- Acceptation : Projection ≠ recrutement certain ; Prospective détaillée par famille et région, effectifs/taux fournis, référence France, navigation vers ROME V3 ; Tracer chaque famille de tri, métropole/DOM/Corse, négatifs et null ; tester la chaîne région → famille → métiers ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. FAP87, 2019–2030, projections ; effectifs et taux fournis base emploi2019, créations/déséquilibre négatifs possibles ; spécificité/part régionales ; agrégats Corse et métropole distincts ; aucune somme BMO.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J, filtres à tester**. Preuves : `02_reponses_observees/indicateurs/prospectiveregions/response_postes_a_pourvoir.json` ; `02_reponses_observees/indicateurs/ProspectiveMetier/response_prospectivemetiers_poste a  pourvoir.json`.
- Test à exécuter : T-E24 : Tracer chaque famille de tri, métropole/DOM/Corse, négatifs et null ; tester la chaîne région → famille → métiers
- Clarification : Q13 : agrégats, géographie et taux ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : FAP87, 2019–2030, projections ; effectifs et taux fournis base emploi2019, créations/déséquilibre négatifs possibles ; spécificité/part régionales ; agrégats Corse et métropole distincts ; aucune somme BMO. ; Pas échelle ROME

## EPIC 8 — Secteurs économiques et salaires sectoriels

**US-E25 — Quels secteurs rémunèrent davantage cette famille ?**

En tant que personne qui explore son avenir professionnel, je veux comparer les salaires sectoriels d'une famille professionnelle.

- Fonction : Salaires par secteur économique. Lot : **L7** ; cible : incluse.
- API : `/salaires/secteurs` (rome, region). Champs et contraintes exacts : ligneE25 de03, Appels_GET_detail, et02.
- Interactions : Salaires par secteur économique ; Salaires par secteur NAF38 dans chaque FAP225 ; référence `ensemble`, parts de salariés et repli ; affichage mensuel/annuel séparé.
- Dépendances : E05;E09;E31.
- Acceptation : Nom FAP sur toute comparaison ; Salaires par secteur NAF38 dans chaque FAP225 ; référence `ensemble`, parts de salariés et repli ; affichage mensuel/annuel séparé ; France/région, plusieurs familles, secteurs absents pour seuil, tranche ouverte, repli d'une seule famille ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. FAP225 x NAF38, BTS2023 ; ensemble référence tous secteurs, parts sous seuil non exhaustives ; maille/repli par ligne ; mêmes unités/tranche ouverte/seuil que E11.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement. null avec tranche ouverte = afficher tranche, pas salaire inventé.
- Validation : **D+J, filtre à tester**. Preuves : `02_reponses_observees/indicateurs/response_salairessecteurs.json`.
- Test à exécuter : T-E25 : France/région, plusieurs familles, secteurs absents pour seuil, tranche ouverte, repli d'une seule famille
- Clarification : Q08 : population, seuil et référence tous secteurs ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : FAP225 x NAF38, BTS2023 ; ensemble référence tous secteurs, parts sous seuil non exhaustives ; maille/repli par ligne ; mêmes unités/tranche ouverte/seuil que E11. ; Pas score attractivité

**US-E26 — Quels secteurs emploient ce métier ?**

En tant que personne qui explore son avenir professionnel, je veux distinguer les secteurs d'emploi de la famille et le contexte économique territorial.

- Fonction : Secteurs d'emploi et contexte économique. Lot : **L7** ; cible : incluse.
- API : `/secteurs` (zonage, territoire, naf) ; `/indicateurs` (rome, zonage, territoire, onisep) ; `/secteurs` (zonage, territoire, rome, naf). Champs et contraintes exacts : ligneE26 de03, Appels_GET_detail, et02.
- Interactions : Secteurs d'emploi et contexte économique ; Deux lectures explicitement séparées : où travaillent les familles (région/France) et dynamique NAF territoriale. Le volet métier-territoire attend résolution R17 ; aucun compte local attribué au métier par jointure.
- Dépendances : E05;E09;E08;E31.
- Acceptation : F1610 => vide ne signifie pas absence employeur ; Deux lectures explicitement séparées : où travaillent les familles (région/France) et dynamique NAF territoriale. Le volet métier-territoire attend résolution R17 ; aucun compte local attribué au métier par jointure ; Reproduire avec/sans ROME sur plusieurs codes/mailles ; conserver 13 lignes R16 et 35 sans filtre comme preuves distinctes ; retester après réponse RCO ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. emploi_secteurs=FAP225 actifs occupés RP2021 région/France ; secteurs=NAF38 SIDE/URSSAF/BODACC selon période ; populations et mailles distinctes, pas de somme FAP ni attribution des comptes territoriaux au métier ; R17 ouvert.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement. R17 vide = anomalie/indisponibilité de ce résultat, pas aucun employeur.
- Validation : **D ; anomalie fournisseur sur les cas R17 ; restitution familiale J via E08**. Preuves : `06_controles/VALIDATION_R17_territoires_secteurs_V2.md` ; `06_controles/resultats/R16 test/GET_indicateurs__rome_F1610__zonage_commune__territoire_34172.json`.
- Test à exécuter : T-E26 : Reproduire avec/sans ROME sur plusieurs codes/mailles ; conserver 13 lignes R16 et 35 sans filtre comme preuves distinctes ; retester après réponse RCO
- Clarification : Q14 : anomalie R17, `metier_maille` et interprétation métier-territoire ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : emploi_secteurs=FAP225 actifs occupés RP2021 région/France ; secteurs=NAF38 SIDE/URSSAF/BODACC selon période ; populations et mailles distinctes, pas de somme FAP ni attribution des comptes territoriaux au métier ; R17 ouvert. ; R17 fournisseur reproduit ; recette finale ouverte sans retirer E26.

## EPIC 9 — Transitions et thèmes de formation

**US-E29 — Quels métiers concernent certaines transitions ?**

En tant que personne qui explore son avenir professionnel, je veux explorer les métiers selon les transitions décrites par leurs tags.

- Fonction : Exploration des transitions. Lot : **L3** ; cible : incluse.
- API : `/metiers/{rome}` (rome) ; `/metiers` (page, domaine). Champs et contraintes exacts : ligneE29 de03, Appels_GET_detail, et02.
- Interactions : Exploration des transitions ; Badges et exploration par tags via filtre local explicitement présenté, combinable avec Domaine ; pas de filtre transition serveur fictif.
- Dépendances : catalogue E01/E04 et E05.
- Acceptation : Tag présent n’annonce aucune embauche ; Badges et exploration par tags via filtre local explicitement présenté, combinable avec Domaine ; pas de filtre transition serveur fictif ; Toutes les pages du catalogue ; true/false/null ; résultats locaux incomplets identifiés jusqu'à fin de collecte ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Tags booléens et null distincts ; filtre local sur catalogue complet, pas classement de croissance ni paramètre transition serveur.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J pour tags ; parcours de liste à tester**. Preuves : `02_reponses_observees/metiers/response_metiers-rome.json` ; `01_sources/openapi/docs_json_interface.json`.
- Test à exécuter : T-E29 : Toutes les pages du catalogue ; true/false/null ; résultats locaux incomplets identifiés jusqu'à fin de collecte
- Clarification : Q01 : stabilité des tags et référentiel ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Tags booléens et null distincts ; filtre local sur catalogue complet, pas classement de croissance ni paramètre transition serveur. ; Pas de recherche dédiée contractuelle

**US-E30 — Quels thèmes de formation sont associés ?**

En tant que personne qui explore son avenir professionnel, je veux passer d'un thème de formation aux certifications puis aux sessions exposées.

- Fonction : Thèmes Formacode et certifications. Lot : **L3** ; cible : incluse.
- API : `/formacodes` (rome, code, domaine, q, page) ; `/certifications` (formacode, page) ; `/certifications/{certifinfo}` (certifinfo) ; `/sessions_a_venir` (certifinfo, zonage, territoire, onisep, page) ; `/sessions_en_cours` (certifinfo, zonage, territoire, onisep, page). Champs et contraintes exacts : ligneE30 de03, Appels_GET_detail, et02.
- Interactions : Thèmes Formacode et certifications ; Thèmes de formation → certifications → sessions publiées ; thème distinct d'une offre de formation ; garder les thèmes sans certification visible.
- Dépendances : E05 ou E17;E20 pour chaîne;E21/E22 pour sessions.
- Acceptation : Ne pas promettre de session à partir du seul thème ; Thèmes de formation → certifications → sessions publiées ; thème distinct d'une offre de formation ; garder les thèmes sans certification visible ; Chaîne complète capturée, pagination et thème sans certification ; pas d'accès sessions non certifiantes par Formacode ; états d'erreur de la ligne vérifiés, aucune preuve HTTP déduite de fixtures.
- Statistiques/règles : Afficher source, période/millésime, définition/unité, grain et géographie effective ; aucun score/delta/agrégat inventé, aucune inférence personnelle ; secret_stat non calculable. Formacode V14 thème et non offre/session ; aucune session non certifiante par Formacode exposée.
- États : Chargement/erreur partielle, 400/401/404/422/429/503/5xx/réseau ; annuler réponse périmée ; null, 0, secret_stat, clé absente et liste vide distincts ; reprise bornée, aucune donnée de remplacement.
- Validation : **D+J, chaîne complète T**. Preuves : `02_reponses_observees/certifications/response_formacode.json` ; `04_relations/CHAINES_APPELS_API.md`.
- Test à exécuter : T-E30 : Chaîne complète capturée, pagination et thème sans certification ; pas d'accès sessions non certifiantes par Formacode
- Clarification : Q10 : couverture des associations et filtres ; tri contractuel/tests/demande fournisseur dans 06 section Q01–Q14.
- Limite contractuelle : Formacode V14 thème et non offre/session ; aucune session non certifiante par Formacode exposée. ; Nécessite confirmation chaîne complète

## Tests de recette transversaux


- Recherche : résultat exact, aucun résultat, plusieurs résultats, pagination, nouvelle recherche depuis fiche, changement de mode.
- ROME V3 : aucune restitution d’un code ROME 4.0.
- OGR : `competence=125416,103659` avec `toutes` et `au_moins_une` ; vérifier divergence attendue 1 contre 3 sur les échantillons.
- Contextes : domaine F16, code 300782 ; avec contexte 10 métiers / sans contexte 3 sur les réponses de référence ; absence du contexte n’est jamais une garantie terrain.
- Territoire : F1610/Montpellier R16 ; vérifier repli et `maille_reelle` indépendamment pour chacune des 14 mesures observées.
- Valeurs : `null`, `0`, `[]`, champ absent, `secret_stat`, mélange mensuel/annuel, famille FAP vs ROME.
- Certifications : alternance des deux intentions ne change pas la source ; RNCP et RS ; pages de blocs.
- Sessions : refuser wording « places disponibles » ; valider le filtre par tests contrastés et garantie RCO, sans inventer d'identifiant ni retirer E21/E22.
- Mes pistes : plafond fixé en D08 (trois proposé), ajout/retrait, deux sélections comparées, sans compte, retour à la recherche.
- Accessibilité : clavier, lecteurs écran, messages d’erreur, contrastes, absence d’information uniquement couleur.

- Mobilités : deux sens et âges, repli par ligne, catégories hors emploi, pas de renormalisation des parts.
- Prospective : tous les effectifs/taux exposés, deux entrées et tris exacts, familles/agrégats, métropole/Corse/DOM, négatifs et null.
- Secteurs : référence ensemble et populations distinctes ; R17 suivi jusqu'à correction/clarification, deux lectures accessibles séparées sans les déclarer équivalentes au résultat attendu.
- Transitions et Formacodes : filtre local sur toutes les pages et chaîne certification/session complète, aucune session non certifiante fabriquée.
- Recette : chacun des 31tests T-E01–T-E31 est tracé ; chaque story distingue statique, fixtures et HTTP. Aucun défaut fournisseur masqué pour déclarer une livraison complète.

## Règle de présentation citoyenne — décision produit du 2 novembre 2026

Les écrans affichent les noms fournis par l’API, sans codes, noms de référentiels, version du projet ni notes de conception. Les paramètres techniques restent dans le code et la documentation. Expliquer les chiffres en langage courant : sens, personnes concernées, lieu, période, unité et limites. Une information manquante n’est pas zéro ; un projet de recrutement n’est pas une offre ; une projection n’est pas une garantie. Conserver les sources. Ne pas ajouter de score, de taux ou de calcul pour vulgariser. Cette règle s’applique aux31 fonctionnalités et à leurs critères de recette. La ligne éditoriale est [documentée ici](12_maquette_html/documentation/REDACTION_CITOYENNE.md).
