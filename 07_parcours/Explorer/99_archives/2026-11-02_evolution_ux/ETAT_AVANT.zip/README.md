# Explorer — guide du dossier

**État au 2 novembre 2026.** Les 31 fonctionnalités E01–E31 sont conservées. Le cadrage L0 est terminé ; une maquette HTML permet de parcourir la présentation citoyenne. L’application de production connectée à l’API reste à réaliser dans son dépôt d’accueil.

## Pour consulter le parcours

**[Ouvrir la maquette HTML](12_maquette_html/index.html)** — un double-clic suffit, sans installation. Les écrans utilisent des noms compréhensibles, expliquent les chiffres et conservent les sources. Les données embarquées sont des observations du dossier ; la maquette ne fait aucun appel à l’API.

[Guide de la maquette et limites](12_maquette_html/README.md) · [Règle de rédaction citoyenne](12_maquette_html/documentation/REDACTION_CITOYENNE.md) · [Aperçu ordinateur](12_maquette_html/apercus/apercu-desktop.png) · [Aperçu mobile](12_maquette_html/apercus/apercu-mobile.png).

## Pour préparer la réalisation

| Fichier | Utilisation |
|---|---|
| [01 — Fonctionnel](01_EXPLORER_V2_FONCTIONNEL.md) | Besoins, parcours et règle de présentation citoyenne. |
| [02 — Spécifications API](02_SPECIFICATIONS_API.md) | 21 GET, paramètres, champs, 29 mesures et précautions statistiques. |
| [03 — Table de conception](03_TABLE_CONCEPTION.csv) | Table commune : 31 lignes, pilotage, appels, preuves, critères et lots. |
| [04 — Backlog](04_BACKLOG_USER_STORIES.md) |31 fonctionnalités et critères de réalisation. |
| [05 — Diagrammes](05_PARCOURS_DIAGRAMMES.md) | Navigation et chaînes fonctionnelles documentées. |
| [06 — Décisions et validations](06_DECISIONS_ET_POINTS_A_VALIDER.md) | Décisions actées, tests manquants et triage Q01–Q14. |
| [07 — Prompt de réalisation](07_PROMPT_CODEX.md) | Instructions pour la future application, après autorisation. |
| [08 — Audit](08_AUDIT_TECHNIQUE_CODEX.md) | Diagnostic API et preuves, avec contexte historique explicite. |
| [09 — Plan](09_PLAN_DE_REALISATION.md) | Lots techniques et dépendances de toute la cible. |
| [10 — Arbitrages](10_DECISIONS_A_ARBITRER.md) | Modalités restant à valider ; périmètre et ligne citoyenne déjà actés. |

Les noms du projet, codes et référentiels ont leur place dans ces documents techniques, pas dans les écrans destinés aux citoyens. Les appels et leurs identifiants restent indispensables aux traitements.

## Organisation

```text
Explorer/
├── README.md                    point d’entrée
├── 01…10                        livrables de travail, noms conservés
├── 11_ux_ui/                    conception, matrice et état Figma
│   └── archives/                premières maquettes, à titre historique
├── 12_maquette_html/
│   ├── index.html               présentation actuelle à ouvrir
│   ├── README.md                utilisation et maintenance
│   ├── sources/                 interface, gabarit et constructeur
│   ├── documentation/           règle éditoriale citoyenne
│   ├── apercus/                 captures de la version actuelle
│   ├── preuves/                 provenance des noms affichables
│   ├── controles/               scripts, résultats et traces
│   └── archives/                anciens textes et script initial
└── 99_archives/                 inventaire et journal du rangement
```

## État des preuves et points ouverts

- Contrat, JSON observé, validation HTTP ciblée et contrôle local restent des preuves distinctes.
- 108 contrôles locaux de la maquette ont réussi sur ordinateur et à 320 pixels ; ils ne valent pas un test HTTP, un test utilisateur ou un audit RGAA.
- Le fichier Figma contient17vues desktop initiales ; le quota du siège a interrompu sa finalisation. Il n’est pas aligné sur toute la rédaction citoyenne actuelle. La maquette HTML est la référence de présentation ; les documents01–10 portent la cible fonctionnelle complète.
- Les questions réellement ouvertes auprès du RCO restent Q01, Q06, Q07, Q11 et Q14 ; Q05 est conditionnelle. Le filtre secteur/métier R17 reste à résoudre. Les tests manquants ne retirent aucune fonctionnalité.
- Aucune donnée, calcul, source externe, table SQL ou relation API supplémentaire n’est introduit.

Les sources de référence hors Explorer sont conservées : contrat/OpenAPI, JSON, UML et matrice API. L’historique des mouvements et les empreintes sont dans [le journal de rangement](99_archives/2026-11-02_nettoyage/README.md). Les anciens visuels ne sont pas des versions concurrentes à utiliser pour le produit.
