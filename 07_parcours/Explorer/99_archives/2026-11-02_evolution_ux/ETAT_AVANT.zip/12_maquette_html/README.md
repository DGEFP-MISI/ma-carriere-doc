# Maquette HTML — présentation citoyenne

**[Ouvrir index.html](index.html)** par double-clic dans le navigateur. Le fichier est autonome et peut être copié seul. Il ne nécessite ni installation ni serveur et n'appelle pas l'API.

La version actuelle emploie les noms fournis, explique les chiffres et retire les mentions internes des écrans. Sources, dates, lieux, unités et limites utiles sont conservés. Les 31 fonctionnalités restent la cible du produit ; la maquette ne constitue pas leur intégration complète à l'API.

## Consulter

- [Fiche métier](index.html#essentiel), [recherche](index.html#recherche), [savoir-faire et conditions](index.html#guide).
- [Certification et sessions](index.html#certification), [domaine professionnel](index.html#domaine).
- [Comparateur couverture/étanchéité](index.html#comparateur), [Mes pistes](index.html#pistes), [sources](index.html#sources).
- [Capture ordinateur](apercus/apercu-desktop.png) et [capture mobile](apercus/apercu-mobile.png).

## Ce qui fonctionne et ce qui reste à réaliser

Les 21 vues sont navigables. Les contrôles portent sur la recherche locale, les pistes temporaires, les deux modes multicompétences du cas observé, les intentions de certification, les sessions à venir/en cours, les onglets de comparaison et les parcours professionnels selon sens et âge disponibles.

La recherche porte sur les fiches embarquées, pas sur tout le catalogue serveur. Une combinaison sans réponse JSON correspondante est signalée, sans résultat fabriqué. Le comparateur illustre couverture/étanchéité et indique les données manquantes du second métier. Montpellier est le lieu de départ disponible ; les chiffres précisent leur lieu réel. Les pistes s'effacent au rechargement ; le plafond de trois est une convention de présentation, pas un arbitrage définitif de stockage.

Les futures intégrations, variantes manquantes et questions RCO restent suivies dans les documents 03, 06 et 10 du dossier parent. Aucune fonctionnalité n'est supprimée parce que la maquette n'en simule pas tous les états.

## Sources, rédaction et maintenance

| Dossier ou fichier | Rôle |
|---|---|
| sources/interface_citoyenne.js | Écrans, interactions et textes actuels. |
| sources/modele.html | Enveloppe HTML et styles, sans ancien script concurrent. |
| sources/construire.py | Assemblage du HTML à partir des fichiers locaux. |
| [Règle éditoriale](documentation/REDACTION_CITOYENNE.md) | Noms publics, explications, portée et limites des chiffres. |
| [Preuves des libellés](preuves/PREUVES_LIBELLES.json) | Correspondance des noms affichables avec les champs et fichiers observés. |
| controles/scripts/ | Vérification navigateur, extraction des résultats et lanceur. |
| controles/resultats/ | Rapports actuels et empreinte d'assemblage. |
| controles/traces/ | Captures DOM brutes, conservées comme preuves. |
| archives/ | Textes et adaptation de libellés antérieurs, à titre historique. |

Depuis la racine du dossier API, reconstruire avec Python 3 :

```powershell
& "$env:LOCALAPPDATA/Programs/Python/Python313/python.exe" -B 07_parcours/Explorer/12_maquette_html/sources/construire.py
```

Relancer les contrôles locaux dans Edge :

```powershell
& ./07_parcours/Explorer/12_maquette_html/controles/scripts/lancer_controles.ps1
```

Les chemins Python et navigateur sont paramétrables dans le lanceur. Le constructeur utilise seulement la bibliothèque standard Python. Les images, le document de contrôle mobile et les traces ne sont pas nécessaires à l'ouverture d'index.html.

## Validation et limites

Dernière recette : **108 contrôles réussis sur ordinateur et 108 à 320 pixels**, avec 21 vues, absence de débordement horizontal et absence de mentions internes, y compris dans les détails. [Rapport ordinateur](controles/resultats/CONTROLE_DESKTOP.json) · [Rapport mobile](controles/resultats/CONTROLE_MOBILE.json).

Ces contrôles ne sont pas des tests HTTP de l'API, des tests avec des utilisateurs ni un audit complet RGAA. L'identification de l'application d'accueil et la finalisation des composants officiels restent nécessaires pour la production. Les erreurs fournisseur déjà connues et les validations manquantes ne sont pas déclarées résolues.
